package com.hcl.java;

public class ArgsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("First Arg" +args[0]);
		System.out.println("Second Arg" +args[1]);

	}

}
