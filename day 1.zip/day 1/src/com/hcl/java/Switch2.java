package com.hcl.java;

public class Switch2 {
	public void check(String op){
		switch(op.toUpperCase()){
		case "INSERT":
			System.out.println("it is inserting");
			break;
		case "COPY":
			System.out.println("its getting copied");
			break;
		default:
			System.out.println("INVALID");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
            String op="INSERT";
            new Switch2().check(op);
	}

}
