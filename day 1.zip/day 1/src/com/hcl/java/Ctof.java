package com.hcl.java;

public class Ctof {
	public void calc(double c){
		double f;
		f=((9*c)/5)+32;
		System.out.println(f);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double c=37;
		Ctof obj=new Ctof();
		obj.calc(c);

	}

}
