package com.hcl.java;

public class Factors {
	public void check(int n){
		int i=1;
		while(i<=n){
			if(n%i==0){
				System.out.println(i);
				
			}
			i++;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=15;
		new Factors().check(n);

	}

}
