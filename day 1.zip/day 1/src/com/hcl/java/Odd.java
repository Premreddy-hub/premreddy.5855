package com.hcl.java;

public class Odd {

	public void show(int n){
		System.out.println("odd1");
		int i=1;
		while(i<n){
			i=i+2;
			System.out.println("odd"+i);
			
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=20;
		new Odd().show(n);

	}

}
