package com.hcl.java;

public class PosNeg {
	public void check(int n){
		if(n<=0){
			System.out.println("Negative Number");
		}
		else{
			System.out.println("Positive Number");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=32;
		PosNeg obj=new PosNeg();
		obj.check(n);

	}

}
