package com.hcl.java;

public class Perfect {
	public void check(int n){
		int i=1;
		int sum=0;
		for(i=1;i<=n/2;i++){
			if(n%i==0){
		      sum=sum+i;
			}
		}
		if(sum==n){
			System.out.println("perfect");
		}
		else{
			System.out.println("not perfect");
		}
	}

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		int n=6;
		new Perfect().check(n);
               
	}

}
