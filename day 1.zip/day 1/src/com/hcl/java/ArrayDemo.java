package com.hcl.java;

public class ArrayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a=new int[]{12,14,46,54};
		System.out.println(("elements of array are"));
	//	for(int i=0;i<a.length;i++){
		//	System.out.println(a[i]);
		//}
		for(int i:a){
			System.out.println(i);
		}

	}

}
