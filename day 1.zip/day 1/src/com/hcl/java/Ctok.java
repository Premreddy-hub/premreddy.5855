package com.hcl.java;

public class Ctok {
	public void calc(double f){
		double c;
		c=273+f;
		System.out.println(c);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double c=37;
		Ctok obj=new Ctok();
		obj.calc(c);
    }

}
