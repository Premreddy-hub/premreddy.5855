package com.hcl.java;

public class Fact {
	public void chec(int n){
		int i=1,f=1;
		while(i<=n){
			f=f*i;
			i++;
		}
		System.out.println("factorial"+"\t"+ f);
		
	}

	public static void main(String[] args) {
		int n=5;
		Fact ob=new Fact();
		ob.chec(n);

	}

}
