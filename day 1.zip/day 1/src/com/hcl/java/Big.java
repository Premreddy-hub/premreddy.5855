package com.hcl.java;

public class Big {
	public void check(int a,int b,int c){
		if(a>b && (a>c)){
			System.out.println("a is Bigger");
		}
		else if((b>c) && (b>a)){
			System.out.println("b is Bigger");
		}
		else if((c>a) && (c>b)){
			System.out.println("c is Bigger");
		}
	}
	public static void main(String[] args) {
		int a=10;
		int b=4;
		int c=6;
		Big ob=new Big();
		ob.check(a, b, c);
		
	}
	

}
