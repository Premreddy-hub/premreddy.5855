package com.hcl.java;

public class Loopdemo {
	public void print(int n){
		int i=0;
		while(i<n){
		System.out.println("Welcome");
		i++;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int n=6;
       new Loopdemo().print(n);
	}

}
