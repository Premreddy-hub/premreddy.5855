package com.hcl.java;

public class ArrayDemo2 {

	public static void main(String[] args) {
		String[] names=new String[]{"ram","prem","raghu","vinod","sai"
		};
		for(String string:names){
			System.out.println(string);
		}
		// TODO Auto-generated method stub

	}

}
