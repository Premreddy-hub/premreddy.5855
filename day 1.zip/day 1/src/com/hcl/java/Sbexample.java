package com.hcl.java;

public class Sbexample {
	public void show(int age,String name,String course,String city){
		StringBuilder sbError=new StringBuilder();
		boolean isValid=true;
		/*validating for age*/
		if(age<=20){
			sbError.append("Age must be greater than 20" + "\r\n");
			isValid=false;
		}
		if(name.indexOf(' ')==-1){
			sbError.append("name must contain both first name and last name" + "\r\n");
			isValid=false;
		}
		if(!course.equalsIgnoreCase("JAVA")){
			sbError.append("only java course allowed..."+"\r\n");
			isValid=false;
			
		}
		if(isValid==true){
		System.out.println("Age  "+age);
		System.out.println("name "+name);
		System.out.println("course "+course);
		System.out.println("city "+city);
		}
		else
		{
		System.out.println(sbError);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age;
		String name;
		String course;
		String city;
        name="prem reddy";
        course="cse";
        age= 19;
        city="bangalore";
        new Sbexample().show(age, name, course, city);
        
	}

}
