package com.hcl.java;

public class Even {
	public void show(int n){
		int i=0;
		while(i<n){
			i=i+2;
			System.out.println("even" +i);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=10;
		new Even().show(n);

	}

}
