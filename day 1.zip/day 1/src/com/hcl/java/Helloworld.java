package com.hcl.java;

/**
 * @author Coalesce
 *
 */
public class Helloworld {
	
	public static void main(String[] args) {
		System.out.println("Hello Robo 2.1");
	}
}
