package com.hcl.boxing;

public class BoxStudent {
	public void show(Object ob){
		Student s=(Student)ob;
		System.out.println(s);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student st=new Student();
		st.sno=21;
		st.name="john";
		st.city="goa";
		st.cgp=87.5;
		new BoxStudent().show(st);

	}

	
}
