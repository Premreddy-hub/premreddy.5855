package com.hcl.boxing;

public class EmpTest {

	public static void main(String[] args) {
		Emp e1=new Emp();
		e1.empno=32;
		e1.name="prem";
		e1.basic=2122;
		Emp e2=new Emp();
		e2.empno=23;
		e2.name="reddy";
		e2.basic=2122;
		System.out.println(e1==e2);
		System.out.println(e1.equals(e2));

	}

}
