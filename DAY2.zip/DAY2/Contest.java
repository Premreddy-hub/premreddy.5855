package com.hcl.boxing;

public class Contest {
	int a,b;

	public Contest() {
		this.a=12;
		this.b=23;
	}

	public Contest(int a, int b) {
		super();
		this.a = a;
		this.b = b;
	}

	@Override
	public String toString() {
		return "Contest [a=" + a + ", b=" + b + "]";
	}
 public static void main(String[]args){
	 Contest c=new Contest();
	 System.out.println(c);
	 Contest y=new Contest(3,5);
	 System.out.println(y);
 }

}
