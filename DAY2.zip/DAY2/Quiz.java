package com.hcl.boxing;

public class Quiz {
	public void check(){
		if(null==null){
			System.out.println("welcome");
		}
		else{
			System.out.println("get lost");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Quiz q=new Quiz();
		q.check();

	}

}
