package com.hcl.boxing;

public class Empsearch {
	public Emp showEmp(int empno)
	{
		Emp emp=null;
		if(empno==1){
			emp=new Emp();
			emp.empno=322;
			emp.name="prem reddy";
			emp.basic=212;
		}
		if(empno==3){
			emp=new Emp();
			emp.empno=213;
			emp.name="oslo";
			emp.basic=323;
		}
		return emp;
	}
	public static void main(String[]args){
		Empsearch e=new Empsearch();
		System.out.println(e.showEmp(3));
		
		
	}
}
