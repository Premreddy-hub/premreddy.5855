package com.hcl.boxing;

public class Condemo {
	static{
		System.out.println("static constructor...");
	}
	
	public Condemo(){
		System.out.println("Default constructor..");
	}
	
	public static void main(String[] args) {
	new Condemo();
		
 	}

}
