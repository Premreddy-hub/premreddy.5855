package com.hcl.boxing;

public class Emp {
	int empno;
	String name;
	double basic;
	
	@Override
	public boolean equals(Object obj) {
		Emp e=(Emp)obj;
		if(e.basic==basic){
			return true;
		}
		else{
			return false;
		}
	}
	@Override
	public String toString() {
		return "Emp [empno=" + empno + ", name=" + name + ", basic=" + basic + "]";
	}
	
	
	

}
