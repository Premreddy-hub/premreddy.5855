package com.hcl.boxing;

public class Time {
	int a,b,c,d;
	
	public Time(){
	this.a=4;
	this.b=76;
	this.c=7;
	this.d=25;
	}
	public void total(){
		int hr=a+c;
		int min=b+d;
		if(min>60){
			min=min-60;
			hr++;
		}
		else{
			min++;
		}
		System.out.println(hr +"hours and "+min +"minutes");
	
	}

	
	public Time(int a, int b, int c, int d) {
		super();
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
		int hr=a+c;
		int min=b+d;
		if(min>60){
			min=min-60;
			hr++;
		}
		else{
			min++;
		}
		System.out.println(hr +"hours and "+min +"minutes");
	
	}
		
	
	@Override
	public String toString() {
		return "Time [a=" + a + ", b=" + b + ", c=" + c + ", d=" + d + "]";
	}
	public static void main(String[]args){
	Time t=new Time();
	Time t2=new Time(2,65,3,15);
	System.out.println(t2);
	
	t.total();
	}

}
