package com.hcl.inh;

 class c1 {
	public void show(){
		System.out.println("from show method");
	}
 }
class c2 extends c1{
	public void display(){
		System.out.println("from display method");
	}
}

	public class Inh{
		
	 public static void main(String[] args) {
		// TODO Auto-generated method stub
		 c2 c=new c2();
		 c.display();
		 c.show();
		
		
		}
	}


