package com.hcl.boxing;

public class Stdemo {
	void show(){
		System.out.println("from show method");
	}
	static void display(){
		System.out.println("from display method");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Stdemo.display();
		new Stdemo().show(); 

	}

}
