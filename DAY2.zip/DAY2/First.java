package com.hcl.inh;

class Second{
	static{
		System.out.println("base static");
	}
	 public void show(){
		 System.out.println("from base class");
	 }
 }
class Third extends Second{
	static{
		System.out.println("derived static");
	}
	public void display(){
		System.out.println("from derived");
	}
}	
  public class First{
  public static void main(String[]args){
	new Second();
	new Third();
	
}
	
}