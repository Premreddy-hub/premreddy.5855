package com.hcl.boxing;

public class Stusearch {
	public Student showstudent(int sno){
		Student s=null;
		if(sno==1){
			s=new Student();
			s.sno=32;
			s.name="sri";
			s.city="tokyo";
			s.cgp=21.3;
		}
		if(sno==2){
			s=new Student();
			s.sno=32;
			s.name="ram";
			s.city="helsinki";
			s.cgp=86.7;
		}
		return s; 
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stusearch s=new Stusearch();
		System.out.println(s.showstudent(1));

	}

}
