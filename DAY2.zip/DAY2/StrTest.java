package com.hcl.boxing;

public class StrTest {
	public void test(String str){
		char[] c=str.toCharArray();
		System.out.println("letter at 5th position is "+c[5]);
	}
	public void check(){
		int i,size=0;
		String str="CongraTulationS";
		
		for(i=0;i<str.length();i++)
		{
			size=i;
			
		}
		System.out.println("length of the string "+size);
		char[] l=str.toCharArray();
		for(i=0;i<str.length();i++){
			if(l[i]>='A'&&l[i]<='Z'){
				int a=l[i]+('a'-'A');
				l[i]=(char)a;
				}
	     	}
		System.out.println(l);
		for(i=0;i<str.length();i++){
			if(l[i]>='a'&&l[i]<='z'){
				int a=l[i]-('a'-'A');
				l[i]=(char)a;
				}
	     	}
		System.out.println(l);
		}
		

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			String str="welcome";
			new StrTest().test(str);
	        new StrTest().check();
		}

	}

				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
	