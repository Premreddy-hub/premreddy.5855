package com.hcl.boxing;

public class BoxEmploy {
	public void show(Object ob){
		Emp e=(Emp)ob;
		System.out.println(e);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Emp op=new Emp();
		op.empno=23;
		op.name="prem";
		op.basic=5099;
		new BoxEmploy().show(op);
		
		

	}

}
