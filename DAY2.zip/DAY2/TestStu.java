package com.hcl.boxing;

public class TestStu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1=new Student();
		s1.name="prem";
		s1.sno=22;
		s1.city="us";
		s1.cgp=32.9;
		
		Student s2=new Student();
		s2.name="reddy";
		s2.sno=43;
		s2.city="us";
		s2.cgp=32.9;
		System.out.println(s1==s2);
		System.out.println(s1.equals(s2));
		
		

	}

}
