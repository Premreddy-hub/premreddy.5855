package com.hcl.inh;

    class One {
    	public void show(){
    		System.out.println("base class");
    	}
    }	
    	class Two extends One{
    		public void show(){
    			
    			System.out.println("child class");
    		}
    	}
    public class Override{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Two().show();
		new One().show();
		One ob=new Two();
		ob.show();
	    Two ob2=new Two();
		ob2.show();
		One o1=(One)ob2;
		o1.show();
	//	One o2=(Two)ob2;
	//	o2.show();*/
	}

	}


