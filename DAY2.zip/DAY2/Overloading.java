package com.hcl.boxing;

public class Overloading {
	public void show(int x){
		System.out.println("w.r.t to int-  " +x);
	}
	public void show(String x){
		System.out.println(("w.r.t to string-  " +x));
	}
	public void show(boolean x){
		System.out.println("w.r.t to boolean-  " +x);
	}
	public void show(double x){
		System.out.println("w.r.t to double-"+ "  " +x);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Overloading o=new Overloading();
		o.show(2);
		o.show("prem");
		o.show(true);
		o.show(12.5);
		

	}

}
