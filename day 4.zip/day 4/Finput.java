package com.hcl.ex;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Finput {
  /**
   * main class.
   * @param args to read the given file.
   */

  public static void main(String[] args) {
    // TODO Auto-generated method stub
    try {
      FileInputStream fin = 
          new FileInputStream("C:/Users/Coalesce/workspace/Day 4/src/com/hcl/ex/Custom.java");
      int ch;
      while ((ch = fin.read()) != -1) {
        System.out.print((char)ch);
      } 
      fin.close();
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

}
