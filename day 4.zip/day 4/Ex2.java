package com.hcl.ex;
/**
 * Exception handling.
 * @author Coalesce user prem.
 *
 */

public class Ex2 {
  /** class.
  * @param a is name.
  * @param b is email.
  * @throws EmailException is thrown.
  * @throws InvalidUserNameException is also thrown.
  */
  public void show(String a,String b) throws EmailException, InvalidUserNameException {
    /**
     * program to handle name and email exceptions.
     */
    boolean flag = true;
    char[] c = b.toCharArray();
    for (char i:c) {
      if (i == '@') {
        flag = false;
      }
    }
    if (flag == true) {
      throw new EmailException("it cannot be an email");
    } else {
      System.out.println(b);
    }
    if (a.length() > 12) {
      throw new InvalidUserNameException("it cannot be bigger");
    } else {
      System.out.println(a);
    }
  }

  /**
  * main function.
  * @param args yoyo.
  * @throws EmailException when it has no '@' in it.
  * @throws InvalidUserNameException.
  **/
  public static void main(String[] args) throws EmailException, InvalidUserNameException {
    // TODO Auto-generated method stub
    String a = "prem reddy";
    String b = "pprem.reddy@hcl.com";
    try {
      new Ex2().show(a, b);
    } catch (InvalidUserNameException | EmailException e) {
      System.out.println(e);
    }
  }  
} 
class InvalidUserNameException extends Exception {
 
  public InvalidUserNameException(String error) {
    super(error);
  }
}
class EmailException extends Exception {
  

  public EmailException(String error) {
    super(error);
  }
}

