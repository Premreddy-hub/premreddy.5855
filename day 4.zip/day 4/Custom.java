package com.hcl.ex;


public class Custom {
  /**
   * class containing logic.
   * @param a is first variable.
   * @param b is second variable.
   * @throws NegativeException is encountered if the input variable is '-'.
   * @throws NumberZeroException is encountered if number is 0.
   */
  public void sum(int a,int b) throws NegativeException, NumberZeroException {
    int c;
    boolean flag = true;
    if (a < 0 || b < 0) {
      flag = false;
      throw new NegativeException("negative number is not allowed");
    }
    if (a == 0 || b == 0) {
      flag = false;
      throw new NumberZeroException("it cannot be zero");
    }
    if (flag == true) {
      c = a + b;
      System.out.println("sum is " + c);
    }
  }
  /**
   * end of function.
   * @param args are variables.
   * @throws NumberZeroException has been thrown.
   */
  
  public static void main(String[] args) throws NumberZeroException {
    int a = 2;
    int b = 2;
    try {
      new Custom().sum(a, b);
    } catch (NegativeException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }catch (NumberZeroException e) {
     e.printStackTrace();	
    }
  }

  class NumberZeroException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NumberZeroException(String error) {
      super(error);
    }
  }
  class NegativeException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NegativeException(String error) {
      super(error);
    }
  }

}
