package com.hcl.ex;

import java.io.File;

public class Fileinfo {
  /**
   * main class.
   * @param args info.
   */

  public static void main(String[] args) {
    // TODO Auto-generated method stub
    File f = new File("C:/Users/Coalesce/workspace/Day 4/src/com/hcl/ex/Custom.java");
    System.out.println("File name" + f.getName());
    System.out.println("File Name" + f.getAbsolutePath());
    File f1 = new File("C:/Users/Coalesce/workspace/Day 4");
    String[] files = f1.list();
    for (String s:files) {
      System.out.println(s);
    }

  }

}
