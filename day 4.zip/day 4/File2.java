package com.hcl.ex;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class File2 {
  /**
   * main class.
   * @param args prints file selected.
   */
  public static void main(String[] args) {
    // TODO Auto-generated method stub
    File f = new File("C:/Users/Coalesce/workspace/Day 4/src/com/hcl/ex/Custom.java");
    try {
      FileReader fr = new FileReader(f);
      //System.out.println(fr);
      int ch;
      try {
        while ((ch = fr.read()) != -1) {
          System.out.print((char)ch);
        }
      } catch (IOException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    } catch (FileNotFoundException e) {
      // TODO Auto-generated catch block
      e.printStackTrace(); 
    }
  }
}