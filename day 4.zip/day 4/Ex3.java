package com.hcl.ex;

public class Ex3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			System.out.println("A");
			throw new NullPointerException();
			//throw new ArithmeticException();
		}catch(ArithmeticException e){
			System.out.println(e);
		}catch(NullPointerException e){
			//System.out.println("Error..");
		
		throw new NumberFormatException();
		}
	catch(NumberFormatException e){
		System.out.println("RethrowsError");
		
	}

	}
}