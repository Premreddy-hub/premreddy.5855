package com.hcl.ex;

public class ThrEx {
  /**
   * main class.
   * @param x is input variable.
   */
  public void show(int x) {
    boolean flag = true;
    if (x < 0) {
      flag = false;
      throw new NumberFormatException("negative numbers are not allowed");
    }
    if (x == 0) {
      flag = false;
      throw new ArithmeticException("Zero is invalid");
    }
    if (flag == true) {
      System.out.println("x value " + x);
    }
  }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         int n=-12;
         try{
        	 new ThrEx().show(n);
         }catch(NumberFormatException e){
        	 System.out.println(e.getMessage());
         }catch(ArithmeticException e){
        	 System.out.println(e.getMessage());
         }
         catch(Exception e){
        	 e.printStackTrace();
         }
         
	}

}
