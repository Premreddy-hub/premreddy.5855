package com.hcl.ex;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Foutput {
  /**
   * main class.
   * @param args is used to print a file in target location.
   */

  public static void main(String[] args) {
    // TODO Auto-generated method stub
    FileInputStream src;
    FileOutputStream tar;
    try {
      src = new FileInputStream("C:/Users/Coalesce/workspace/Day 4/src/com/hcl/ex/Custom.java");
      tar = new FileOutputStream("c:/files/target.txt");
      int ch;
      while ((ch = src.read()) != -1) {
        tar.write((char)ch);
      }
      src.close();
      tar.close();
      System.out.println("***FILE COPIED***");
    } catch (FileNotFoundException e) {
      e.getStackTrace();
    } catch (IOException e) {
      e.getStackTrace();
    }
  }
}
