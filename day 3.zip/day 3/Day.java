package com.hcl.day3;


enum DayCheck{
	MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY
}
 
  public  class Day{
	  public void show(){
		  DayCheck[] arrDayCheck=DayCheck.values();
		    for(DayCheck DayCheck:arrDayCheck){
		    	System.out.println(DayCheck);
		    }
	  }
    public static void main(String[] args) {
		// TODO Auto-generated method stub
    DayCheck d=DayCheck.WEDNESDAY;
    System.out.println(d);
    new Day().show();
    	

	}

	}
