package com.hcl.day3;

public class Quiz {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Object[] arr=new Object[]
				{
	12,"Welcome",12.5,"HCL",'A',"java",true,11,11.6,"Bangalore"
				};
        for(Object object:arr){
        	if(object instanceof Integer){
        		System.out.println(object);
        	}
        }
	}

}
