package com.hcl.day3;

public class Attendance {
	// to give new values
	public static void display(Object...ob){
		for(Object obj:ob){
			System.out.println(obj + " ");
		
		}
	}
	public static void show(int rollno ,String...name){
		for(String s:name){
			System.out.println(rollno+"\t" +s+ " ");
			}
		System.out.println();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		show(2);
		show(1,"john");
		show(6,"prem","reddy");
		show(9,"sai","sri","ram");
		
		display();
		display("nani",28,"snow");

	}

}
