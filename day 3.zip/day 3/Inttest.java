package com.hcl.inter;
interface In1{
	default void city(){
		System.out.println("city of I1");
	}
}
interface In2{
	default void city(){
		System.out.println("city of I2");
	}
}
interface I3{
	default void city(){
		System.out.println("city of I3");
	}
}
class Demo implements In1,In2,I3{

	@Override
	public void city() {
		// TODO Auto-generated method stub
		In1.super.city();
		In2.super.city();
		I3.super.city();
		
	}
	
}
public class Inttest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Demo().city();

	}

}
