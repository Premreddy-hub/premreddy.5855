package com.hcl.exception;
class First{
	public  void show(){
		System.out.println("base class");
	}
}
class Second extends First{
	 public   void show(){
		System.out.println("child class");
	}
}

public class Inhex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        First ob=new First();
        try {
			Second ob2=(Second)ob;
			ob2.show();
		}catch(ClassCastException e){
			System.out.println("Object creation went wrong");
		}
        catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
