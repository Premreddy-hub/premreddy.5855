package com.hcl.exception;

public class Div {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b,c;
		try {
			a=Integer.parseInt(args[0]);
			b=Integer.parseInt(args[1]);
			c=a/b;
			System.out.println("divisor "+ c);
		}catch(ArithmeticException e) {
			System.out.println("Number cannot be divided by Zero");
		}
		catch(NumberFormatException e){
			System.out.println("You cannot insert a string");
		}
		catch(ArrayIndexOutOfBoundsException e){
			System.out.println("You havent inserted any argument");
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			System.out.println("Winterfell");
		}

	}

}
