package com.hcl.day3;
enum test{
	A,B,X,Y,P,C,N;
	private test(){
		System.out.println("hello");
	}

}
	

public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		  for(test t:test.values()){
	    	  System.out.println(t); 
	       }
	}

}
