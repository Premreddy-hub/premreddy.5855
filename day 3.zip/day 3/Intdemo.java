package com.hcl.inter;
interface Itraining{
	void name();
	void email();
}

class Prem implements Itraining{

	@Override
	public void name() {
		// TODO Auto-generated method stub
		System.out.println("prem reddy");
	}

	@Override
	public void email() {
		// TODO Auto-generated method stub
		System.out.println("premreddy.5855");
	}
	
}
class Nilesh implements Itraining{

	@Override
	public void name() {
		// TODO Auto-generated method stub
		System.out.println("nilesh kumar singh");
	}

	@Override
	public void email() {
		// TODO Auto-generated method stub
		System.out.println("kumarsingh386");
	}
	
}
public class Intdemo {

	public static void main(String[] args) {
		Itraining it=new Prem();
		Itraining it1=new Nilesh();
		Itraining[] arrit=new Itraining[]{it,it1};
		for(Itraining t:arrit){
			t.name();
			t.email();
		}

	}

}
