package com.hcl.inter;

interface I1{
	void name();
}
interface I2{
	void id();
	void email();
}
 
class Employ implements I1,I2{

	@Override
	public void id() {
		// TODO Auto-generated method stub
		System.out.println(115);
	}

	@Override
	public void email() {
		// TODO Auto-generated method stub
		System.out.println("premreddy.5855");
	}

	@Override
	public void name() {
		// TODO Auto-generated method stub
		System.out.println("Prem Reddy");
	}
	
}
public class Multi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employ e1=new Employ();
		e1.name();
		e1.email();
		e1.id();

	}

}
