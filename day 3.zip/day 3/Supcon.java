package com.hcl.day3;
class Employ{
	int empno;
	String name;
	double basic;
	
	@Override
	public String toString() {
		return "Employ [empno=" + empno + ", name=" + name + ", basic=" + basic + "]";
	}

	public Employ(int empno, String name, double basic) {
		super();
		this.empno = empno;
		this.name = name;
		this.basic = basic;
	}
	
}
class Amit extends Employ{

	public Amit(int empno, String name, double basic) {
		super(empno, name, basic);
		// TODO Auto-generated constructor stub
	}
	
}
class Prem extends Employ{

	public Prem(int empno, String name, double basic) {
		super(empno, name, basic);
		// TODO Auto-generated constructor stub
	}
	
}
public class Supcon{
	public static void main(String[]args){
		Employ e1=new Amit(1,"amit",22000);
		Employ e2=new Prem(115,"Prem",32000);
	//	System.out.println(e1);
	//	System.out.println(e2);
        Employ[] arrEmploy=new Employ[]{e1,e2};   		
		for(Employ emp:arrEmploy ){
			System.out.println(emp);
		}
	
	}
}




