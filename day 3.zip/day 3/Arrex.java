package com.hcl.exception;

public class Arrex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			int[] arr=new int[]{2,3};
			arr[10]=5/0;
		}catch(ArrayIndexOutOfBoundsException e){
			System.out.println("shut");
		}
		catch(ArithmeticException e){
			System.out.println("Cannot be divided by Zero");
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
